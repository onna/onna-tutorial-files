use std::path::PathBuf;
use structopt::StructOpt;

use tokio::fs::File;
use tokio::prelude::*;

use std::fmt;

use anyhow::Result;

use reqwest;
use reqwest::header;
use chrono::NaiveDate;
use serde::{Serialize, Deserialize};


#[derive(Debug, StructOpt)]
#[structopt(
    name = "onna-logs",
    about = "Exporting logs from Onna."
)]
struct Opt {

    #[structopt(
        long = "username",
        env = "ONNA_USERNAME",
        help = "Service Account username"
    )]
    username: String,
    
    #[structopt(
        long = "password",
        env = "ONNA_PASSWORD",
        help = "password"
    )]
    password: String,
    
    #[structopt(
        long = "account",
        env = "ONNA_ACCOUNT",
        help = "the Onna account name"
    )]
    account: String,
        
    #[structopt(
        long = "account-url",
        env = "ONNA_ACCOUNT_URL",
        help = "the URL of your account, e.g https://company.onna.io or https://enterprise.onna.com"
    )]
    account_url: String,
    
    #[structopt(
        long = "from-date",
        env = "ONNA_FROM_DATE",
        help = "start date. format: %Y-%m-%d"
    )]
    from_date: NaiveDate,

    #[structopt(
        long = "to-date",
        env = "ONNA_TO_DATE",
        help = "end date. format: %Y-%m-%d"
    )]
    to_date: NaiveDate,

    #[structopt(
        long = "fname",
        env = "ONNA_FNAME",
        parse(from_os_str),
        help = "name of the file"
    )]
    fname: PathBuf,

    #[structopt(
        long = "container",
        env = "ONNA_CONTAINER",
        default_value = "rel0",
        help = "name of the account container"
    )]
    container: String
}


// Auth code
#[derive(Serialize, Deserialize, Debug)]
struct OnnaAuthCode
{
    auth_code: String
}

impl OnnaAuthCode
{
    async fn new(url: &str)
        -> Result<OnnaAuthCode>
    {
        let resp = reqwest::get(url)
            .await?
            .json::<OnnaAuthCode>()
            .await?;
        
        Ok(resp)
    }
}


// Jwt Token
#[derive(Serialize, Deserialize, Debug)]
struct JwtToken
{
    token: String
}

#[derive(Serialize, Deserialize, Debug)]
struct JwtTokenPayload<'a>
{
    grant_type: &'static str,
    code: &'a str,
    username: &'a str,
    password: &'a str,
    scopes: Vec<&'a str>,
    client_id: &'static str
}

impl JwtToken {

    async fn new<'a>(
            auth_code: &OnnaAuthCode,
            username: &'a str,
            password: &'a str,
            scope: &'a str,
            base_url: &'a str)
        -> Result<JwtToken>
    {
        let url: String = format!("{}/auth/oauth/get_auth_token", base_url);
        
        let payload = JwtTokenPayload {
            grant_type: "user",
            code: &auth_code.auth_code,
            username,
            password,
            scopes: vec![scope],
            client_id: "canonical"
        };
        
        let client = reqwest::Client::new();
        let resp = client.post(&url)
            .json(&payload)
            .send()
            .await?;
        
        let resp = resp.text().await?;
        
        Ok( JwtToken { token: resp } )
    }

}

impl fmt::Display for JwtToken 
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) 
        -> fmt::Result 
    {
        write!(f, "{}", self.token)
    }
}


// activity log
#[derive(Serialize, Deserialize, Debug)]
struct ActivityLogPayload 
{
    epoch_from: i64,
    epoch_to: i64
}

async fn activity_log<'a>(
        dt_from: NaiveDate,
        dt_to: NaiveDate,
        jwt_token: &JwtToken,
        base_url: &'a str,
        account: &'a str,
        container: &'a str,
        file: &mut File
    )
    -> Result<()>
{
    let url: String = format!("{}/api/{}/{}/@activityLog", base_url, container, account);
    
    let mut headers = header::HeaderMap::new();
    headers.insert(
        header::AUTHORIZATION,
        header::HeaderValue::from_str(
            format!("Bearer {}", jwt_token).as_ref(),
        )?
    );

    let client = reqwest::Client::builder()
        .default_headers(headers)
        .build()?;
    
    let payload = ActivityLogPayload {
        epoch_from: dt_from.and_hms(0, 0, 0).timestamp(),
        epoch_to: dt_to.and_hms(0, 0, 0).timestamp()
    };
    
    let mut resp = client.post(&url)
        .json(&payload)
        .send()
        .await?;
        
    // write into the file directly
    while let Some(chunk) = resp.chunk().await? {
        file.write_all(chunk.as_ref()).await?;
    }
    
    Ok(())
}


#[tokio::main()]
async fn main() -> Result<()>
{
    let args = Opt::from_args();
    
    let auth_code_url: String = format!("{}/api/{}/{}/@oauthgetcode?client_id=canonical&scope={}",
        &args.account_url,
        &args.container,
        &args.account,
        &args.account);

    let code = OnnaAuthCode::new(&auth_code_url)
        .await
        .expect("Error getting the auth code.");
    // println!("{:?}", code);

    let token = JwtToken::new(
            &code, 
            &args.username, 
            &args.password, 
            &args.account, 
            &args.account_url)
        .await
        .expect("Error getting the auth token.");
    // println!("{:?}", token);
    
    // file creation
    let filename = format!("{}_user_activity_{}-{}",
        args.fname.display(),
        args.from_date,
        args.to_date);
    println!("Writing to file {}", filename);
        
    let mut file = File::create(filename)
        .await
        .expect("File creation failed.");

    // get activity log
    activity_log(
            args.from_date,
            args.to_date,
            &token,
            &args.account_url,
            &args.account,
            &args.container,
            &mut file)
        .await
        .expect("Error getting the logs.");
        
    Ok(())
}
