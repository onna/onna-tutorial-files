# onna-auditlogs

Get auditlogs from Onna

```
onna-logs \
    --account <account> \
    --account-url <account-url> \
    --fname <fname> \
    --from-date <from-date> \
    --password <password> \
    --to-date <to-date> \
    --username <username>
```
